/*
	* Mid Terms for PWA-1
*/
