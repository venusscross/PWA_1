/**
 * Created by venuscross on 5/23/14.
 */
//Name: Venus Cross
//Date:May 24,2014
//Assignment: Debug It

// self executing function
(function(){

  console.log("FIGHT!!!");



})();